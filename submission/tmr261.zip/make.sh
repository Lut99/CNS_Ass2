#!/bin/bash

# Simply runs 'make clean && make exploit'
make clean && make exploit
